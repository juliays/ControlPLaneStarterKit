# Resource Group module

Module for creating a resource group.
