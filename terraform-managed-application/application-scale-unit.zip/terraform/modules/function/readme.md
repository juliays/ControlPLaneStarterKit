# Function module

Module for creating an app service plan and a function app inside.
