# Event Hub module

Module for creating an event hub namespace and event hub.
