# Storage Account module

Module for creating a storage account.
