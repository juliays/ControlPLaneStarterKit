# Scale Unit Terraform script

This terraform script will create a "scale unit" that consists of the following resources:

1. Resource Group
2. Storage Account
3. Event Hub
4. Function App
5. Java function deployed from a blob URL
